REAC favicon files

Place all files in the repository root, alongside index.html (or the main HTML file).
If your site uses a public/ folder for static assets, put them in public/ instead and
adjust the href paths in the HTML accordingly.

Add these lines inside the <head> section of the main HTML file:

<link rel="icon" href="/favicon.ico" sizes="any">
<link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
<link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
<link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="192x192" href="/android-chrome-192x192.png">
<link rel="icon" type="image/png" sizes="512x512" href="/android-chrome-512x512.png">

Recommended sizes:
- favicon.ico: includes 16, 32, 48, and 64 px variants
- favicon-16x16.png: 16 × 16 px
- favicon-32x32.png: 32 × 32 px
- apple-touch-icon.png: 180 × 180 px (iPhone/iPad home screen)
- android-chrome-192x192.png: 192 × 192 px
- android-chrome-512x512.png: 512 × 512 px

These are all generated from the supplied REAC logo.
